# Commit Candidates

- Generated UTC: `2026-09-09T09:10:22.722477+00:00`
- Branch: `feature/evidence-bundle-pipeline`
- HEAD: `3c6aef5bb1995887f4e553a2a7954f83eb7cecb7`

## Safety

- Suggestions only.
- No `git add` commands were generated.
- No files were staged.
- No commit was created.
- Review every exact path before using Git.

## Candidate 1: Continuity Pipeline

- Verdict: `POTENTIAL CANDIDATE`
- File count: `13`
- Notes: Review the continuity tools together. Generated notebook_bundle outputs are not included.

### Files

- `.continuity/last_bundle_manifest.json`
- `docs/REPOSITORY_CHECKPOINT.md`
- `scripts/end_of_day.sh`
- `tools/classify_working_tree.py`
- `tools/generate_bundle_change_report.py`
- `tools/generate_notebook_bundle.py`
- `tools/generate_session_recovery_pack.py`
- `tools/install_continuity_extensions.py`
- `tools/install_working_tree_classifier.py`
- `tools/patch_end_of_day.py`
- `tools/upgrade_working_tree_classifier.py`
- `tools/validate_canonical_sync.py`
- `tools/validate_notebook_bundle.py`

## Candidate 2: General Documentation

- Verdict: `REVIEW AND PARTITION`
- File count: `11`
- Notes: Group runbooks and specifications by feature or workflow.

### Files

- `docs/F3_D3_BATCH_11_RUNBOOK.md`
- `docs/F3_D3_WAIVER_ACTION_PLAN_SPEC.md`
- `docs/PHASE_F2_RUNBOOK.md`
- `docs/database/MIGRATIONS.md`
- `docs/database/PARITY_STATUS.md`
- `docs/database/SCHEMA.md`
- `docs/packages/PACKAGE_C0_SEASON_SANDBOX.md`
- `docs/packages/PACKAGE_C_OWNER_OPERATIONS.md`
- `docs/runbooks/MOCK_K_DEF_UPGRADE.md`
- `docs/runbooks/PROJECT_AUDIT.md`
- `docs/runbooks/SEASON_READINESS.md`

## Candidate 3: Production Source

- Verdict: `HUMAN REVIEW REQUIRED`
- File count: `23`
- Notes: Pair only with directly related tests after reviewing intent.

### Files

- `app.py`
- `intelligence_operations_routes.py`
- `recommendation_explainability_batch_4a_fixed/test_recommendation_explainer.py`
- `ingestion/__init__.py`
- `ingestion/ingest_weekly_data.py`
- `ingestion/ingestion_store.py`
- `ingestion/ingestion_validation.py`
- `intelligence/__init__.py`
- `intelligence/balanced_recommendation_score.py`
- `intelligence/candidate_filter.py`
- `intelligence/decision_ranking.py`
- `intelligence/dynamic_need_model.py`
- `intelligence/intelligence_calibration.py`
- `intelligence/intelligence_explainability.py`
- `intelligence/intelligence_readiness.py`
- `intelligence/intelligence_reconciliation.py`
- `intelligence/model_calibration.py`
- `intelligence/player_survival_probability.py`
- `intelligence/recommendation_explainer.py`
- `intelligence/scarcity_model.py`
- `intelligence/survival_calibration.py`
- `services/intelligence/services_matchup_intelligence.py`
- `services/intelligence/services_trade_target_center.py`

## Candidate 4: Draft Intelligence

- Verdict: `HUMAN REVIEW REQUIRED`
- File count: `13`
- Notes: Review draft-domain ownership and pair with relevant tests.

### Files

- `draft_accuracy_routes.py`
- `draft_health_routes.py`
- `draft/__init__.py`
- `draft/adaptive_draft_reconciliation.py`
- `draft/draft_coach_sleeper_fusion.py`
- `draft/draft_decision_plan.py`
- `draft/draft_hq_integrity.py`
- `draft/draft_operations_hardening.py`
- `draft/draft_outcome_health.py`
- `draft/draft_outcome_tracker.py`
- `draft/draft_readiness.py`
- `draft/draft_state_hardening.py`
- `draft/reconciled_draft_decision.py`

## Candidate 5: Tests

- Verdict: `PAIR WITH IMPLEMENTATION`
- File count: `14`
- Notes: Do not create a broad tests-only group without reviewing ownership.

### Files

- `tests/test_batch_b_outcome_intelligence.py`
- `tests/test_batch_d_intelligence_operations.py`
- `tests/test_draft_day_readiness.py`
- `tests/test_draft_environment_rotation.py`
- `tests/test_draft_hq_snapshot_integrity.py`
- `tests/test_draft_operations_hardening.py`
- `tests/test_draft_state_hardening.py`
- `tests/test_f4_c_decision_ranking.py`
- `tests/test_mock_draft_synchronization.py`
- `tests/test_recommendation_explainer.py`
- `tests/test_survival_calibration.py`
- `tests/test_f3_d3_waiver_action_plan.py`
- `tests/test_import.py`
- `tests/test_model_calibration.py`

## Candidate 6: Audit Evidence

- Verdict: `SEPARATE EVIDENCE REVIEW`
- File count: `109`
- Notes: Keep generated evidence separate from production implementation.

### Files

- `audit/f3_b2/reconciliation/VERIFICATION_RESULTS.md`
- `audit/f3_b2/reconciliation/pytest_output.txt`
- `audit/f3_b2/reconciliation/verification.json`
- `audit/f3_b3/verification/VERIFICATION_RESULTS.md`
- `audit/f3_b3/verification/pytest_output.txt`
- `audit/f3_b3/verification/verification.json`
- `audit/f3_b4/verification/VERIFICATION_RESULTS.md`
- `audit/f3_b4/verification/verification.json`
- `audit/f3_d4/verification/VERIFICATION_RESULTS.md`
- `audit/f3_d4/verification/pytest_output.txt`
- `audit/f3_d4/verification/verification.json`
- `audit/__init__.py`
- `audit/f3_b1/SUMMARY.md`
- `audit/f3_b1/constraint_references.txt`
- `audit/f3_b1/git_branch.txt`
- `audit/f3_b1/git_log.txt`
- `audit/f3_b1/git_status.txt`
- `audit/f3_b1/pytest_collection.txt`
- `audit/f3_b1/pytest_version.txt`
- `audit/f3_b1/python_version.txt`
- `audit/f3_b1/replay_code_references.txt`
- `audit/f3_b1/repository_files.txt`
- `audit/f3_b1/source_capture/GIT_COMMIT.txt`
- `audit/f3_b1/source_capture/GIT_STATUS.txt`
- `audit/f3_b1/source_capture/INTEGRATION_REFERENCES.txt`
- `audit/f3_b1/source_capture/MANIFEST.txt`
- `audit/f3_b1/source_capture/PYTEST_VERSION.txt`
- `audit/f3_b1/source_capture/PYTHON_VERSION.txt`
- `audit/f3_b1/source_capture/README.md`
- `audit/f3_b1/source_capture/TEST_COLLECTION.txt`
- `audit/f3_b1/source_capture/app.py`
- `audit/f3_b1/source_capture/draft_events/__init__.py`
- `audit/f3_b1/source_capture/draft_events/runtime.py`
- `audit/f3_b1/source_capture/draft_events/service.py`
- `audit/f3_b1/source_capture/draft_events/sleeper_ingestion.py`
- `audit/f3_b1/source_capture/draft_events/store.py`
- `audit/f3_b1/source_capture/migrations/007_draft_event_pipeline.sql`
- `audit/f3_b1/source_capture/pytest.ini`
- `audit/f3_b1/source_capture/requirements.txt`
- `audit/f3_b1/source_capture/scripts/replay_failed_draft_events.py`
- `audit/f3_b1/source_capture/services/sleeper_service.py`
- `audit/f3_b1/source_capture/tests/fixtures/draft_events.json`
- `audit/f3_b1/source_capture/tests/test_draft_event_pipeline.py`
- `audit/f3_b1/source_capture/tests/test_f3a1_repository_integration.py`
- `audit/f3_b1/source_capture/tests/test_f3a2_runtime.py`
- `audit/f3_b31/postgres_parity/VERIFICATION_RESULTS.md`
- `audit/f3_b31/postgres_parity/pytest_output.txt`
- `audit/f3_b31/postgres_parity/verification.json`
- `audit/f3_b31/postgres_parity/verification_blocked.json`
- `audit/f3_d3/verification/VERIFICATION_RESULTS.md`
- `audit/f3_d3/verification/pytest_output.txt`
- `audit/f3_d3/verification/verification.json`
- `audit/phase_f/F2R_B_MAPPING_AUDIT.md`
- `audit/phase_f/draft_recommendation_function.txt`
- `audit/phase_f/example-run/draft_report.md`
- `audit/phase_f/example-run/recommendation_snapshots.jsonl`
- `audit/phase_f/f2_interface_candidates.json`
- `audit/phase_f/f2_recommendation_review.txt`
- `audit/phase_f/high_priority_candidates.txt`
- `audit/phase_f/mock_recommendations_function.txt`
- `audit/phase_f/player_insert_paths.txt`
- `audit/phase_f/player_sync_paths.txt`
- `audit/phase_f/player_update_paths.txt`
- `audit/phase_f/players_identity_candidates.txt`
- `audit/phase_f/players_identity_columns.txt`
- `audit/phase_f/sleeper_draft_calls.txt`
- `audit/phase_f/sleeper_endpoints.txt`
- `audit/phase_f/sleeper_pick_calls.txt`
- `audit/phase_f/sleeper_player_calls.txt`
- `audit/phase_f/sleeper_player_map_schema.txt`
- `audit/phase_f/sleeper_player_map_usage.txt`
- `audit/phase_f/sleeper_player_matching_code.txt`
- `audit/phase_f/sleeper_player_sample.json`
- `audit/post_draft_batch0/SUMMARY.txt`
- `audit/post_draft_batch0/active_files.txt`
- `audit/post_draft_batch0/db_skipped.txt`
- `audit/post_draft_batch0/flask_routes.txt`
- `audit/post_draft_batch0/git_branch.txt`
- `audit/post_draft_batch0/git_diff_check.txt`
- `audit/post_draft_batch0/git_head.txt`
- `audit/post_draft_batch0/git_log.txt`
- `audit/post_draft_batch0/git_status.txt`
- `audit/post_draft_batch0/post_draft_references.txt`
- `audit/post_draft_batch0/py_compile.txt`
- `audit/post_draft_batch0/relevant_tests.txt`
- `audit/post_draft_batch0/source__app.py.txt`
- `audit/post_draft_batch0/source__owner_operations.py.txt`
- `audit/post_draft_batch0/source__services__sleeper_service.py.txt`
- `audit/post_draft_batch0/source__sleeper_hub.py.txt`
- `audit/post_draft_batch0/source__sleeper_intelligence.py.txt`
- `audit/post_draft_batch0/source__sleeper_intelligence_routes.py.txt`
- `audit/post_draft_batch0/source__templates__base.html.txt`
- `audit/post_draft_batch0/source__templates__gm.html.txt`
- `audit/post_draft_batch0/source__templates__league_overview.html.txt`
- `audit/post_draft_batch0/source__templates__lineup.html.txt`
- `audit/post_draft_batch0/source__templates__sleeper_intelligence.html.txt`
- `audit/post_draft_batch0/source__templates__team.html.txt`
- `audit/post_draft_batch0/source__templates__trades.html.txt`
- `audit/post_draft_batch0/source__templates__waivers.html.txt`
- `audit/post_draft_batch0/tracked_files.txt`
- `audit/tools/__init__.py`
- `audit/tools/audit_fantasy_intelligence.py`
- `audit/tools/audit_yahoo_pickem.py`
- `audit/tools/recommendation_engine_audit.py`
- `reports/PICKEM_INPUT_CENTER_REPORT.txt`
- `reports/PICKEM_POSTGRES_FIX_REPORT.txt`
- `reports/YAHOO_PICKEM_INSTALL_REPORT.txt`
- `reports/trade_intelligence.txt`
- `reports/weekly_lineup_intelligence.txt`

## Candidate 7: Recovery and Automation Utilities

- Verdict: `DURABLE OR TEMPORARY REVIEW`
- File count: `40`
- Notes: Separate durable tools from one-time repair and discovery scripts.

### Files

- `scripts/run_batch_e.py`
- `tools/validate_draft_readiness.py`
- `batch_jobs/__init__.py`
- `batch_jobs/batch_e_common.py`
- `batch_jobs/batch_e_injuries.py`
- `batch_jobs/batch_e_market_bridge.py`
- `batch_jobs/batch_e_ratings.py`
- `batch_jobs/batch_e_weather.py`
- `scripts/apply_f3a2_runtime_patch.py`
- `scripts/collection/cache_sleeper_players.py`
- `scripts/collection/collect_regular_season_integrity_batch_inputs.py`
- `scripts/collection/collect_trade_intelligence_batch_inputs.py`
- `scripts/collection/collect_weekly_lineup_batch1_inputs.py`
- `scripts/collection/inspect_weekly_lineup_intelligence.py`
- `scripts/f3_b1_batch1_audit.sh`
- `scripts/f3_b1_capture_implementation_sources.sh`
- `scripts/find_commit_blockers.sh`
- `scripts/maintenance/apply_f3_b31_postgres_parity_patch_v2.py`
- `scripts/maintenance/apply_rehearsal_doc_updates.py`
- `scripts/maintenance/fix_final_doc_cleanup.py`
- `scripts/maintenance/fix_weekly_template_test.py`
- `scripts/maintenance/install_v1_7_draft_day_readiness.py`
- `scripts/maintenance/patch_owner_operations.py`
- `scripts/maintenance/patch_owner_operations_batch3.py`
- `scripts/maintenance/patch_trade_template_compat.py`
- `scripts/maintenance/patch_trade_template_legacy_headings.py`
- `scripts/maintenance/reconcile_rehearsal_docs.py`
- `scripts/maintenance/update_f3_d4_documentation.py`
- `scripts/maintenance/update_rehearsal_docs.py`
- `scripts/patch_f3_d3_waiver_action_plan.py`
- `scripts/repo_cleanup_apply.sh`
- `scripts/repo_cleanup_preview.sh`
- `scripts/repo_inventory.py`
- `scripts/repo_size_report.sh`
- `scripts/reporting/build_batch2_source_pdf.py`
- `scripts/reporting/build_batch3_source_pdf.py`
- `scripts/reporting/build_f4_pdfs.py`
- `scripts/reporting/export_source_to_pdf.py`
- `scripts/verify_f3_d3_action_plan.py`
- `tools/update_docs.py`

## Excluded From Automatic Commit Candidates

### Sensitive or Never Commit

- None

### Deleted Files Requiring Manual Review

- ` D` `MOCK_K_DEF_UPGRADE.md`
- ` D` `PACKAGE_C0_SEASON_SANDBOX.md`
- ` D` `PACKAGE_C_OWNER_OPERATIONS.md`
- ` D` `PICKEM_INPUT_CENTER_REPORT.txt`
- ` D` `PICKEM_POSTGRES_FIX_REPORT.txt`
- ` D` `PROJECT_AUDIT.md`
- ` D` `SEASON_READINESS.md`
- ` D` `YAHOO_PICKEM_INSTALL_REPORT.txt`
- ` D` `adaptive_draft_reconciliation.py`
- ` D` `audit_fantasy_intelligence.py`
- ` D` `audit_yahoo_pickem.py`
- ` D` `balanced_recommendation_score.py`
- ` D` `batch_e_common.py`
- ` D` `batch_e_injuries.py`
- ` D` `batch_e_market_bridge.py`
- ` D` `batch_e_ratings.py`
- ` D` `batch_e_weather.py`
- ` D` `cache_sleeper_players.py`
- ` D` `candidate_filter.py`
- ` D` `draft_coach_sleeper_fusion.py`
- ` D` `draft_decision_plan.py`
- ` D` `draft_operations_hardening.py`
- ` D` `draft_outcome_health.py`
- ` D` `draft_outcome_tracker.py`
- ` D` `draft_readiness.py`
- ` D` `draft_state_hardening.py`
- ` D` `dynamic_need_model.py`
- ` D` `fantasy_intelligence_mocklab_v1.sql`
- ` D` `ingest_weekly_data.py`
- ` D` `ingestion_store.py`
- ` D` `ingestion_validation.py`
- ` D` `install_v1_7_draft_day_readiness.py`
- ` D` `intelligence_calibration.py`
- ` D` `intelligence_explainability.py`
- ` D` `intelligence_readiness.py`
- ` D` `intelligence_reconciliation.py`
- ` D` `model_calibration.py`
- ` D` `player_survival_probability.py`
- ` D` `recommendation_engine_audit.py`
- ` D` `recommendation_explainer.py`
- ` D` `reconciled_draft_decision.py`
- ` D` `scarcity_model.py`
- ` D` `survival_calibration.py`
- ` D` `survivor_store.py.bak`
- ` D` `test_import.py`

### Unknown or Human Review Required

- ` M` `.gitignore`

### Generated Outputs

- `??` `end_of_day_status.txt`
- `??` `f4_pdf_build/build_bundle_pdf.py`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/README.txt`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/checkpoint.txt`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/f4_symbol_search.txt`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/git_cached_names.txt`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/git_cached_stat.txt`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/git_diff_check.txt`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/git_diff_names.txt`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/git_diff_stat.txt`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/git_log.txt`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/git_status.txt`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/missing_candidates.txt`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/pytest_collection.txt`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/python_version.txt`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/repository_inventory.txt`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/.ai/agents/development_director.md`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/.ai/agents/postgres_guardian.md`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/.ai/agents/release_manager.md`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/.ai/agents/repository_guardian.md`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/DEVELOPMENT_ROADMAP.md`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/PROJECT_STATE.md`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/PROJECT_STATUS.md`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/app.py`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/database/schema.sql`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/docs/F3_D1_SLEEPER_WAIVER_SPEC.md`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/docs/F3_D3_WAIVER_ACTION_PLAN_SPEC.md`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/docs/NEXT_SESSION_HANDOFF.md`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/migrations/001_mock_draft_lab.sql`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/migrations/002_season_sandbox.sql`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/migrations/003_owner_operations.sql`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/migrations/003_yahoo_pickem.sql`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/migrations/004_weekly_intelligence.sql`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/migrations/004_yahoo_pickem_postgres.sql`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/migrations/005_pickem_feed_runs.sql`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/migrations/005_sleeper_full_integration.sql`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/migrations/006_draft_outcome_tracking.sql`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/migrations/006_market_intelligence.sql`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/migrations/007_draft_day_readiness.sql`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/migrations/007_draft_event_pipeline.sql`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/migrations/007_survivor_intelligence.sql`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/migrations/008_intelligence_operations.sql`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/migrations/009_data_ingestion_pipeline.sql`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/migrations/010_draft_event_pipeline_upgrade.sql`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/migrations/F2R_C_001_sleeper_local_identity.sql`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/owner_operations.py`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/services/publication_gate.py`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/services/roster_slots.py`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/services/trade_intelligence.py`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/services/weekly_lineup_intelligence.py`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/sleeper_intelligence.py`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/sleeper_intelligence_routes.py`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/templates/dashboard.html`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/templates/gm.html`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/templates/lineup.html`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/templates/team.html`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/templates/trades.html`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/tests/test_f3_d1_sleeper_waiver_intelligence.py`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/tests/test_f3_d3_waiver_action_plan.py`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/tests/test_f3_d4_waiver_action_integration.py`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/tests/test_f3_d5_waiver_action_publication.py`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/tests/test_f3_d5_waiver_action_route.py`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/tests/test_f3_d5_waiver_action_template.py`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/tests/test_trade_intelligence.py`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/tests/test_trade_intelligence_template.py`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/tests/test_weekly_lineup_intelligence.py`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/tests/test_weekly_lineup_template.py`
- `??` `f4_pdf_build/f4_discovery_20260908T062649Z/source/weekly_intelligence.py`
- `??` `f4_pdf_build/f4_discovery_bundle.pdf`
- `??` `notebook_bundle/BUNDLE_MANIFEST.json`
- `??` `notebook_bundle/BUNDLE_VALIDATION.json`
- `??` `notebook_bundle/BUNDLE_VALIDATION.md`
- `??` `notebook_bundle/CANONICAL_SYNC_VALIDATION.json`
- `??` `notebook_bundle/CANONICAL_SYNC_VALIDATION.md`
- `??` `notebook_bundle/CHANGE_REPORT.json`
- `??` `notebook_bundle/CHANGE_REPORT.md`
- `??` `notebook_bundle/DEVELOPMENT_ROADMAP.md`
- `??` `notebook_bundle/IMPLEMENTATION_INVENTORY.md`
- `??` `notebook_bundle/MIGRATIONS.md`
- `??` `notebook_bundle/NEXT_SESSION_HANDOFF.md`
- `??` `notebook_bundle/PARITY_STATUS.md`
- `??` `notebook_bundle/PREVIOUS_BUNDLE_MANIFEST.json`
- `??` `notebook_bundle/PROJECT_STATE.md`
- `??` `notebook_bundle/PROJECT_STATUS.md`
- `??` `notebook_bundle/REPOSITORY_CHECKPOINT.md`
- `??` `notebook_bundle/SCHEMA.md`
- `??` `notebook_bundle/SESSION_START.json`
- `??` `notebook_bundle/SESSION_START.md`
- `??` `notebook_bundle/TEST_INVENTORY.md`
- `??` `notebook_bundle/WORKING_TREE_CLASSIFICATION.json`
- `??` `notebook_bundle/WORKING_TREE_CLASSIFICATION.md`

### Temporary Patches

- `??` `patches/f3_d4a_roster_truth_hardening.patch`
- `??` `patches/post_draft_recovery.patch`

### Backups and Archives

- `??` `reference_snapshot/DEVELOPMENT_ROADMAP.md`
- `??` `reference_snapshot/NEXT_SESSION_HANDOFF.md`
- `??` `reference_snapshot/PROJECT_STATE.md`
- `??` `reference_snapshot/PROJECT_STATUS.md`
- `??` `reference_snapshot/git_status.txt`
- `??` `reference_snapshot/head.txt`
